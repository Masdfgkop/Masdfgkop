# Multi-Language Support

- These all are the languages currently available in Yukki Music Bot. You can edit or change all strings available.

| Code | Language | Contributor |
|-|-------|-------|
| en | English | Thanks to [elkatib](https://t.me/Mk_74_UU)
