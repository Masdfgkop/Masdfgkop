
import asyncio

import os
import time
import requests
from config import START_IMG_URL
from pyrogram import filters
from pyrogram import Client
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup
from strings.filters import command
from YukkiMusic import (Apple, Resso, SoundCloud, Spotify, Telegram, YouTube, app)
from YukkiMusic import app


@app.on_message(
    command(["سورس مين","سورس","السورس","يا سورس"])
    & ~filters.edited
)
async def khalid(client: Client, message: Message):
    await message.reply_photo(
        photo=f"https://telegra.ph/file/1803618a25212c26ea24a.jpg",
        caption=f"""[◍ 𝒘𝒆𝒍𝒄𝒐𝒎𝒆 𝒕𝒐 𝒔𝒐𝒖𝒓𝒄𝒆 ⌁ 𝗩𝗲𝗴𝗮](https://t.me/VEGA_source)\n\n[◍ 𝒕𝒉𝒆 𝒃𝒆𝒔𝒕 𝒔𝒐𝒖𝒓𝒄𝒆 𝒐𝒏 𝒕𝒆𝒍𝒆𝒈𝒓𝒂𝒎 √🌐](https://t.me/VEGA_source)\n\n[◍ 𝒇𝒐𝒍𝒍𝒐𝒘 𝒕𝒉𝒆 𝒃𝒖𝒕𝒕𝒐𝒏𝒔 𝒃𝒆𝒍𝒐𝒘 √🔮](https://t.me/VEGA_source)\n\n||[𝗦𝗼𝘂𝗿𝗰𝗲 𝗩𝗲𝗴𝗮](https://t.me/KIMMY50)||""",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "⋆༄ًِ⸙⃟꯭𝗞ْٖiَٖ𝗠ًَِٰٖ𝗠ًَِ𝗬♱𝙓⃟⃟⃟⃟⃟⃟‌🇫🇷℘➸ 𝘼ٍ𝙇ٍ 𝟯𝘼ٍ𝙎𝘼ٍ𝘽ٍ𝘼☬𑲭𑲭𑲭𑲭𑲭𑲭", url=f"https://t.me/KIMMY50"), 
                ],[
                    InlineKeyboardButton(
                        "𝗦𝗼𝘂𝗿𝗰𝗲 𝗩𝗲𝗴𝗮", url=f"https://t.me/VEGA_source"),
                ],[
                    InlineKeyboardButton(
                        "اضغط لاضافه البوت لمجموعتك✅.", url=f"https://t.me/Ko_7_bot?startgroup=true"),
                ],

            ]

        ),

    )


